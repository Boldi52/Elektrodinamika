package com.example.elektrodinamika;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText editVoltage, editCurrent, editTime;
    TextView textPowerResult, textEnergyResult;
    double power = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editVoltage = findViewById(R.id.editVoltage);
        editCurrent = findViewById(R.id.editCurrent);
        editTime = findViewById(R.id.editTime);

        textPowerResult = findViewById(R.id.textPowerResult);
        textEnergyResult = findViewById(R.id.textEnergyResult);

        Button buttonPower = findViewById(R.id.buttonPower);
        Button buttonEnergy = findViewById(R.id.buttonEnergy);

        buttonPower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatePower();
            }
        });

        buttonEnergy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateEnergy();
            }
        });
    }

    private void calculatePower() {
        if (editVoltage.getText().toString().isEmpty() ||
                editCurrent.getText().toString().isEmpty()) {

            Toast.makeText(this, "Add meg az U és I értékeket!", Toast.LENGTH_SHORT).show();
            return;
        }

        double voltage = Double.parseDouble(editVoltage.getText().toString());
        double current = Double.parseDouble(editCurrent.getText().toString());

        power = voltage * current;
        textPowerResult.setText("Teljesítmény: " + power + " W");
    }

    private void calculateEnergy() {
        if (editTime.getText().toString().isEmpty()) {
            Toast.makeText(this, "Add meg az időt!", Toast.LENGTH_SHORT).show();
            return;
        }

        double time = Double.parseDouble(editTime.getText().toString());
        double energy = power * time;

        textEnergyResult.setText("Felhasznált energia: " + energy + " Wh");
    }
}